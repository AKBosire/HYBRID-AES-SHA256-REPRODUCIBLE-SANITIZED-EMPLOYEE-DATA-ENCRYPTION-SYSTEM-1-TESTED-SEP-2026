"""Local-only comparison application for an authorized Wireshark HTTP demonstration."""

from flask import Flask, request


app = Flask(__name__)


@app.route("/", methods=["GET", "POST"])
def form():
    if request.method == "POST":
        return "Synthetic form received. This local HTTP demonstration is intentionally unencrypted."
    return """
    <h1>Local Insecure HTTP Comparison</h1>
    <p>Use fabricated values only. Do not expose this server to a network.</p>
    <form method="post">
      <label>Email <input name="email" value="synthetic@example.invalid"></label><br>
      <label>Password <input name="password" value="fabricated-password"></label><br>
      <button type="submit">Submit synthetic data</button>
    </form>
    """


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5001, debug=False, use_reloader=False)
